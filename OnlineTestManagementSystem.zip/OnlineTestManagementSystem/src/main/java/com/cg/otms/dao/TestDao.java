package com.cg.otms.dao;

public class TestDao {

}
