package com.cg.otms.dao;

public class QuestionsDao {

}
